#!/bin/bash
cd ~/Desktop/alexa-avs-sample-app/samples
cd companionService && sudo npm start

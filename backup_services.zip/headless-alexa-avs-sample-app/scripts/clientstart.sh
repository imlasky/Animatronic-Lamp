#!/bin/bash
cd ~/Desktop/alexa-avs-sample-app/samples
cd javaclient && sudo mvn exec:exec

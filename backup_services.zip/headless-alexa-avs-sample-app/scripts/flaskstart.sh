#!/bin/bash
cd /home/pi/Luxo
sleep 10
source env/bin/activate
python Luxo_main.py

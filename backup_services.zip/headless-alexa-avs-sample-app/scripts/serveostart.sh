#!/bin/bash
sleep 10
ssh -R 80:localhost:5000 serveo.net

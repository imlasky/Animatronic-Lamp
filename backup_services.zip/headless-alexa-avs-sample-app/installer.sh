#!/bin/bash
read -r -p "Have you checked the Alexa App location specified in the scripts? (Y/N)" verify_interrupt
case ${verify_interrupt} in
            [yY] )
                echo "Continuing ..."
            ;;
            * )
                echo "Installation interrupted. Please change the alexa app location in the scripts."
                exit
            ;;
esac
sudo chmod +x /home/pi/headless-alexa-avs-sample-app/scripts/clientstart.sh
sudo chmod +x /home/pi/headless-alexa-avs-sample-app/scripts/companionstart.sh
sudo chmod +x /home/pi/headless-alexa-avs-sample-app/scripts/service-installer.sh
sudo chmod +x /home/pi/headless-alexa-avs-sample-app/scripts/wakeword.sh
sudo chmod +x /home/pi/headless-alexa-avs-sample-app/scripts/serveostart.sh
sudo chmod +x /home/pi/headless-alexa-avs-sample-app/scripts/flaskstart.sh
sudo /home/pi/headless-alexa-avs-sample-app/scripts/service-installer.sh
sudo systemctl enable luxocompanionapp.service
sudo systemctl enable luxoclient.service
sudo systemctl enable luxowakeword.service
sudo systemctl enable luxoserveo.service
sudo systemctl enable luxoflask.service
sudo systemctl start luxocompanionapp.service
sudo systemctl start luxoclient.service
sudo systemctl start luxowakeword.service
sudo systemctl start luxoserveo.service
sudo systemctl start luxoflask.service

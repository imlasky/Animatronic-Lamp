import sys
def print_test(i):
    while True:
        print('subtest'+str(i))

if __name__ == '__main__':
    print_test(sys.argv[1])

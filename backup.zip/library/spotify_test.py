import spotipy
import sys
from spotipy.oauth2 import SpotifyClientCredentials
import time
import json

client_credentials_manager = SpotifyClientCredentials(client_id='f50cb471fc2c4bfab79c43539df778be',
                                                              client_secret='7966d94d2fef4064b4702d0896615aaf')
spotify = spotipy.Spotify(client_credentials_manager=client_credentials_manager)

if len(sys.argv) > 1:
    name = ' '.join(sys.argv[1:])
else:
    name = 'Bahamas'

if len(sys.argv) > 1:
    tid = sys.argv[1]
else:
    tid = 'spotify:track:4TTV7EcfroSLWzXRY6gLv6'


spotify.player.load(tid)
spotify.player.play()
#start = time.time()
#analysis = spotify.audio_analysis(tid)
#delta = time.time() - start
#print(json.dumps(analysis, indent=4))
#print ("analysis retrieved in %.2f seconds" % (delta,))
#lz_uri = 'spotify:artist:36QJpDe2go2KgaRleHCDTp'
#results = spotify.artist_top_tracks(lz_uri)
#for track in results['tracks'][:10]:
#    print('track    : ' + track['name'])
#    print('audio    : ' + track['preview_url'])
#    print('cover art: ' + track['album']['images'][0]['url'])

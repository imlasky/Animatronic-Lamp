#!/bin/bash
sleep 10
. /home/pi/Documents/Animatronic-Lamp/env/bin/activate
aplay /home/pi/gotmail.wav
cd /home/pi/Documents/Animatronic-Lamp/assistant-sdk-python/google-assistant-sdk/googlesamples/assistant/library/
echo 'Starting hotword.py'
python --version
python hotword.py --device_model_id main_brain > /home/pi/logs/new_log


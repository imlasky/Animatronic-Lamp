import servos
import numpy as np
import time

servo0 = servos.Servo(250, 600, 0)
servo1 = servos.Servo(527, 225, 1)
servo2 = servos.Servo(154, 382, 2)
servo3 = servos.Servo(105, 620, 3)

servo0.set_pos(0)
servo1.set_pos(0)
servo2.set_pos(0)
servo3.set_pos(0)

servo0_pos = 0
servo1_pos = 0
servo2_pos = 0
servo3_pos = 0

add_num = 0.05

while True:

    key = input('')

    if key == 'w':
        servo2_pos += 0.05
        servo2.set_servo_pulse(0, 1500)
        servo2.set_pos(servo2_pos)
    elif key == 's':
        servo2_pos -= 0.05
        servo2.set_pos(servo2_pos)
    elif key == 'd':
        servo3_pos += 0.05
        servo3.set_pos(servo3_pos)
    elif key == 'a':
        servo3_pos -= 0.05
        servo3.set_pos(servo3_pos)
    elif key == 'p':
        servo1_pos += 0.05
        servo1.set_pos(servo1_pos)
    elif key == 'l':
        servo1_pos -= 0.05
        servo1.set_pos(servo1_pos)

    #servo1_pos += add_num
    #servo1.set_pos(servo1_pos)
    #if servo1_pos >= 1:
    #    add_num = -add_num
    #elif servo1_pos <= -1:
    #    add_num = -add_num
    #time.sleep(0.3)
    #print(servo1_pos)

#    print([servo1_pos, servo2_pos, servo3_pos])


